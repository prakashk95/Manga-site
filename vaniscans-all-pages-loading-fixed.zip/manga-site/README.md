# VaniScans — Netlify Deploy-Ready Manga & Webtoon Hub

## Project Structure

```text
manga-site/
├── frontend/
│   ├── index.html          # Main SPA entry point
│   ├── _redirects          # Netlify SPA & /adminpanel routing rules
│   ├── css/
│   │   └── style.css       # Custom neon & reader styles
│   ├── js/
│   │   ├── main.js         # App logic, instant #adminpanel router & Admin Studio
│   │   ├── api.js          # All fetch() calls, SHA-256 hashing & IndexedDB storage
│   │   └── reader.js       # Webtoon & Single-Page reader + Ad slot injection
│   └── assets/
├── backend/
│   ├── server.js           # Node.js + Express API & static server
│   ├── routes/
│   │   └── manga.js        # API routes
│   ├── controllers/
│   │   └── mangaController.js
│   ├── data/
│   │   └── manga.json      # Initial seed database
│   └── package.json
├── netlify/
│   └── functions/
│       └── api.js          # Serverless SHA-256 auth verification for Netlify
├── netlify.toml            # Zero-config Netlify deployment settings
└── README.md
```

## How to Deploy on Netlify (2 Easy Ways)

### Option A: Drag & Drop (Fastest)
1. Unzip `vaniscans-manga-site.zip`.
2. Go to [app.netlify.com/drop](https://app.netlify.com/drop).
3. Drag and drop the **`frontend`** folder (or the entire `manga-site` folder) directly onto the page.
4. Your site will be live immediately!

### Option B: GitHub / Git Integration
1. Push the `manga-site` folder to a GitHub repository.
2. Connect the repo in Netlify.
3. `netlify.toml` automatically configures:
   - **Publish directory:** `frontend`
   - **Functions directory:** `netlify/functions`

## Accessing the Admin Panel
- **URL:** `https://your-domain.com/#adminpanel` or `https://your-domain.com/adminpanel`
- **Keyboard Shortcut:** Press `Ctrl + Shift + A` or `Alt + A` from any page.
- **Security:** Your username and password are **never stored in plaintext** anywhere in the source code. Only their 256-bit cryptographic SHA-256 hashes exist in the codebase:
  - **Username SHA-256:** `059a50ce956b7ec61527c7ecc0c55b5a009dc54ab4acddce8852b46baa2aba30`
  - **Password SHA-256:** `9109551a88284a2754a704d50d6636fc596ae718df126354742f1637940bbc5a`
